﻿Public Class frmLogin

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblheading.Click

    End Sub

    Private Sub btnlogIn_Click(sender As Object, e As EventArgs) Handles btnlogIn.Click
        If txtDrivername.Text = "Isheunesu" And txtDriverID.Text = "R44" Then

            Me.Hide()
            frmMainMenu.Show()

        Else
            MsgBox("Login failure!!")

        End If

    End Sub
    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()

    End Sub
End Class
