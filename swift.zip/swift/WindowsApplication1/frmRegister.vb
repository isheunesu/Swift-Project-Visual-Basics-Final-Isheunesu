﻿Public Class frmRegister

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtPlatenumber.TextChanged

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim Name As String
        Dim Surname As String
        Dim DriverID As String
        Dim Sex As String
        Dim TruckName As String
        Dim TruckModel As String
        Dim PlateNumber As String

        If txtName.Text = "" Then
            MsgBox("Name can not be empty!")
            txtName.Focus()
        Else
            Name = txtName.Text
        End If
        If txtSurname.Text = "" Then
            MsgBox("Suname can not be empty!")
            txtSurname.Focus()
        Else
            Surname = txtSurname.Text
        End If
        If txtID.Text = "" Then
            MsgBox("ID can not be empty!")
            txtID.Focus()
        Else
            DriverID = txtID.Text
        End If
        If radMale.Checked = False And radFemale.Checked = False Then

            MsgBox("Please check Male or Female")


        ElseIf radMale.Checked = True Then
            Sex = "Male"
        ElseIf radFemale.Checked = True Then
            Sex = "Female"
        End If
        If txtTruckname.Text = "" Then
            MsgBox("Truck Name can not be empty!")
            txtTruckname.Focus()
        Else
            TruckName = txtTruckname.Text
        End If
        If txtTruckmodel.Text = "" Then
            MsgBox("Model can not be empty!")
            txtTruckname.Focus()
        Else
            TruckModel = txtTruckmodel.Text
        End If
        If txtPlatenumber.Text = "" Then
            MsgBox("Platenumber can not be empty!")
            txtPlatenumber.Focus()
        Else
            PlateNumber = txtPlatenumber.Text
            MsgBox("resistration successful")
            Me.Close()
        End If

    End Sub


    Private Sub txtTruckname_TextChanged(sender As Object, e As EventArgs) Handles txtTruckname.TextChanged

    End Sub

    Private Sub txtTruckmodel_TextChanged(sender As Object, e As EventArgs) Handles txtTruckmodel.TextChanged

    End Sub
End Class