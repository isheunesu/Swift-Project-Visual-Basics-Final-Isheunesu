﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ProfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VehicleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.EfeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip3 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.WefrweferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProfileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PersonalDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TrucksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegisterVehicleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveVehicleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TripsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompletedTripsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PostponedTripsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpcomingTripsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FAQToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.ContextMenuStrip3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(109, 26)
        '
        'ProfileToolStripMenuItem
        '
        Me.ProfileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VehicleToolStripMenuItem})
        Me.ProfileToolStripMenuItem.Name = "ProfileToolStripMenuItem"
        Me.ProfileToolStripMenuItem.Size = New System.Drawing.Size(108, 22)
        Me.ProfileToolStripMenuItem.Text = "Profile"
        '
        'VehicleToolStripMenuItem
        '
        Me.VehicleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TripsToolStripMenuItem})
        Me.VehicleToolStripMenuItem.Name = "VehicleToolStripMenuItem"
        Me.VehicleToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.VehicleToolStripMenuItem.Text = "Vehicle"
        '
        'TripsToolStripMenuItem
        '
        Me.TripsToolStripMenuItem.Name = "TripsToolStripMenuItem"
        Me.TripsToolStripMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.TripsToolStripMenuItem.Text = "Trips"
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EfeToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(91, 26)
        '
        'EfeToolStripMenuItem
        '
        Me.EfeToolStripMenuItem.Name = "EfeToolStripMenuItem"
        Me.EfeToolStripMenuItem.Size = New System.Drawing.Size(90, 22)
        Me.EfeToolStripMenuItem.Text = "efe"
        '
        'ContextMenuStrip3
        '
        Me.ContextMenuStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WefrweferToolStripMenuItem})
        Me.ContextMenuStrip3.Name = "ContextMenuStrip3"
        Me.ContextMenuStrip3.Size = New System.Drawing.Size(127, 26)
        '
        'WefrweferToolStripMenuItem
        '
        Me.WefrweferToolStripMenuItem.Name = "WefrweferToolStripMenuItem"
        Me.WefrweferToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.WefrweferToolStripMenuItem.Text = "wefrwefer"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileToolStripMenuItem1, Me.TrucksToolStripMenuItem, Me.TripsToolStripMenuItem1, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(284, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProfileToolStripMenuItem1
        '
        Me.ProfileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PersonalDetailsToolStripMenuItem, Me.UpdateInfoToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.ProfileToolStripMenuItem1.Name = "ProfileToolStripMenuItem1"
        Me.ProfileToolStripMenuItem1.Size = New System.Drawing.Size(53, 20)
        Me.ProfileToolStripMenuItem1.Text = "Profile"
        '
        'PersonalDetailsToolStripMenuItem
        '
        Me.PersonalDetailsToolStripMenuItem.Name = "PersonalDetailsToolStripMenuItem"
        Me.PersonalDetailsToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.PersonalDetailsToolStripMenuItem.Text = "Personal Details"
        '
        'UpdateInfoToolStripMenuItem
        '
        Me.UpdateInfoToolStripMenuItem.Name = "UpdateInfoToolStripMenuItem"
        Me.UpdateInfoToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.UpdateInfoToolStripMenuItem.Text = "Update Info"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'TrucksToolStripMenuItem
        '
        Me.TrucksToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisterVehicleToolStripMenuItem, Me.RemoveVehicleToolStripMenuItem})
        Me.TrucksToolStripMenuItem.Name = "TrucksToolStripMenuItem"
        Me.TrucksToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.TrucksToolStripMenuItem.Text = "Trucks"
        '
        'RegisterVehicleToolStripMenuItem
        '
        Me.RegisterVehicleToolStripMenuItem.Name = "RegisterVehicleToolStripMenuItem"
        Me.RegisterVehicleToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.RegisterVehicleToolStripMenuItem.Text = "Register Vehicle"
        '
        'RemoveVehicleToolStripMenuItem
        '
        Me.RemoveVehicleToolStripMenuItem.Name = "RemoveVehicleToolStripMenuItem"
        Me.RemoveVehicleToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.RemoveVehicleToolStripMenuItem.Text = "Remove Vehicle"
        '
        'TripsToolStripMenuItem1
        '
        Me.TripsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompletedTripsToolStripMenuItem, Me.PostponedTripsToolStripMenuItem, Me.UpcomingTripsToolStripMenuItem})
        Me.TripsToolStripMenuItem1.Name = "TripsToolStripMenuItem1"
        Me.TripsToolStripMenuItem1.Size = New System.Drawing.Size(45, 20)
        Me.TripsToolStripMenuItem1.Text = "Trips"
        '
        'CompletedTripsToolStripMenuItem
        '
        Me.CompletedTripsToolStripMenuItem.Name = "CompletedTripsToolStripMenuItem"
        Me.CompletedTripsToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.CompletedTripsToolStripMenuItem.Text = "Completed Trips"
        '
        'PostponedTripsToolStripMenuItem
        '
        Me.PostponedTripsToolStripMenuItem.Name = "PostponedTripsToolStripMenuItem"
        Me.PostponedTripsToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.PostponedTripsToolStripMenuItem.Text = "Postponed Trips"
        '
        'UpcomingTripsToolStripMenuItem
        '
        Me.UpcomingTripsToolStripMenuItem.Name = "UpcomingTripsToolStripMenuItem"
        Me.UpcomingTripsToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.UpcomingTripsToolStripMenuItem.Text = "Upcoming Trips"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FAQToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'FAQToolStripMenuItem
        '
        Me.FAQToolStripMenuItem.Name = "FAQToolStripMenuItem"
        Me.FAQToolStripMenuItem.Size = New System.Drawing.Size(97, 22)
        Me.FAQToolStripMenuItem.Text = "FAQ"
        '
        'frmMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMainMenu"
        Me.Text = "MainMenu"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ContextMenuStrip3.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ProfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VehicleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents EfeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip3 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents WefrweferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ProfileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PersonalDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TrucksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegisterVehicleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveVehicleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TripsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompletedTripsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PostponedTripsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpcomingTripsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FAQToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
